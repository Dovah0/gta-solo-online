$PATH = "change me"

cd $PATH
.\pssuspend.exe gta5
Start-Sleep -s 10
.\pssuspend.exe gta5 -r
EXIT